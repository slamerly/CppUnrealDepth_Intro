// Copyright Epic Games, Inc. All Rights Reserved.


#include "UE5_INTRODUCTIONGameModeBase.h"


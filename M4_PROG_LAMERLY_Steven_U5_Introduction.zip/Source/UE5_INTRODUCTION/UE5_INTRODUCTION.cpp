// Copyright Epic Games, Inc. All Rights Reserved.

#include "UE5_INTRODUCTION.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, UE5_INTRODUCTION, "UE5_INTRODUCTION" );
